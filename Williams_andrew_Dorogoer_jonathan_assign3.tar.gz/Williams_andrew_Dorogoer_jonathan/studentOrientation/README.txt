CS442 Design Patterns
Fall 2016
PROJECT 3 README FILE

Due Date: Friday, October 28, 2016
Submission Date: Friday, October 28, 2016
Grace Period Used This Project: 0
Grace Period Remaining: Not sure
Author(s): Andrew Williams
	   Jonathan Dorogoer
e-mail(s): awilli64@binghamton.edu
	   jdorogo1@binghamton.edu

PURPOSE:

[
	Helps students to create an orientation schedule
]

ANT INSTRUCTIONS:

[

## To clean:
ant clean

## To compile: 
ant all

## To generate javadocs:
ant doc

## To run:
ant run

## To create tarball for submission
ant tarzip
]


DATA STRUCTURES:

[
None.  We only store a few actual variables, and they are stored as ints
]

TIME COMPLEXITY:

[
	O(1) Despite all the interfaces and classes, this program doesn't do anything.  There is not a single loop in it, nor is there any recursion.
]
