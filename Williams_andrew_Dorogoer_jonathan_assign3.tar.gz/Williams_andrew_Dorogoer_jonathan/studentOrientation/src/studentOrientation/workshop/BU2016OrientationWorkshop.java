package studentOrientation.workshop;

import studentOrientation.schedule.OrientationSchedule;

public class BU2016OrientationWorkshop implements FreshmanOrientationWorkshop {
    
    /**
     *construct method to call in driver, calls the build methods for all schedule options
     *
     *@param sched OrientationSchedule object
     */
    public void construct(OrientationSchedule sched) {
		sched.buildCampusTour();
		sched.buildBookStore();
		sched.buildDorm();
		sched.buildRegistration();
    }
}
