package studentOrientation.workshop;

import studentOrientation.schedule.OrientationSchedule;

public interface FreshmanOrientationWorkshop {
    public void construct(OrientationSchedule sched);
}
