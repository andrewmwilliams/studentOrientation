package studentOrientation.enums;

public enum BookStoreOptions { CAMPUS_BOOK_STORE, MANDO_BOOKS }
