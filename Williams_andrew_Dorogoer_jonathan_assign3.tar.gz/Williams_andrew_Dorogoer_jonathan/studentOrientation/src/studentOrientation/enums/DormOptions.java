package studentOrientation.enums;

public enum DormOptions { ADMIN_OFFICE, ONLINE_CONTEST };
