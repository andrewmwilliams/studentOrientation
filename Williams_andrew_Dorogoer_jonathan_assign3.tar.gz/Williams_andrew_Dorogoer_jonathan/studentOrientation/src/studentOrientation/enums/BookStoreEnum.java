package studentOrientation.enums;

public enum BookStoreEnum {
	MandoBookStore(100, 60, 50, 20),
	CampusBookStore(104, 30, 20, 20);

	public final double cost;
	public final double duration;
	public final double effort;
	public final double footprint;
/**
 *
 *BookStoreEnum constructor
 *
 *@param costIn intial cost
 *@param durationIn intial duration
 *@param effortIn initial effort
 *@param footprintIn initial footprintIn
 */
	BookStoreEnum(double costIn, double durationIn, double effortIn, double footprintIn) {
		cost = costIn;
		duration = durationIn;
		effort = effortIn;
		footprint = footprintIn;
	}
}
