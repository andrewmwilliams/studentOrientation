package studentOrientation.enums;

public enum RegistrationOptions { REGISTRARS_OFFICE, COMPUTER_LAB };
