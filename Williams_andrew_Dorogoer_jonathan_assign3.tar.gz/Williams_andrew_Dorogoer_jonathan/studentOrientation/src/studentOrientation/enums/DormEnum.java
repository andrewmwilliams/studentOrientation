package studentOrientation.enums;

public enum DormEnum {
	AdminOffice(100, 20, 20, 2),
	Online(102, 5, 10, 2);

	public final double cost;
	public final double duration;
	public final double effort;
	public final double footprint;
/**
 *DormEnum contructor
 *
 *@param costIn intial cost
 *@param durationIn intial duration
 *@param effortIn initial effort
 *@param footprintIn initial footprintIn
 */

	DormEnum(double costIn, double durationIn, double effortIn, double footprintIn) {
		cost = costIn;
		duration = durationIn;
		effort = effortIn;
		footprint = footprintIn;
	}
}
