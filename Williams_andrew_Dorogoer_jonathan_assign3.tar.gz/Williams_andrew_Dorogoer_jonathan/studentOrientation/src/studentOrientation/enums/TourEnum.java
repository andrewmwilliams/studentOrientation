package studentOrientation.enums;

public enum TourEnum {
	OnFoot(2, 30, 50, 2),
	ByBus(0.1, 10, 15, 50);

	public final double cost;
	public final double duration;
	public final double effort;
	public final double footprint;
/**
 *TourEnum constructor
 *
 *@param costIn intial cost
 *@param durationIn intial duration
 *@param effortIn initial effort
 *@param footprintIn initial footprintIn
 */

	TourEnum(double costIn, double durationIn, double effortIn, double footprintIn) {
		cost = costIn;
		duration = durationIn;
		effort = effortIn;
		footprint = footprintIn;
	}
}
