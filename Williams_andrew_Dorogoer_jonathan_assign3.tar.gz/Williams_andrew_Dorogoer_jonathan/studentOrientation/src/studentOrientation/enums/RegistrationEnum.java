package studentOrientation.enums;

public enum RegistrationEnum {
	Online(100, 10, 5, 2),
	Registrar(97, 15, 15, 5);

	public final double cost;
	public final double duration;
	public final double effort;
	public final double footprint;
/**
 * RegistrationEnum constructor 
 *
 *@param costIn intial cost
 *@param durationIn intial duration
 *@param effortIn initial effort
 *@param footprintIn initial footprintIn
 */

	RegistrationEnum(double costIn, double durationIn, double effortIn, double footprintIn) {
		cost = costIn;
		duration = durationIn;
		effort = effortIn;
		footprint = footprintIn;
	}
}
