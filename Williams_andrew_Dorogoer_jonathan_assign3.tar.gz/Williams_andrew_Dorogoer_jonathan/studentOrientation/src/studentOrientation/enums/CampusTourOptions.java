package studentOrientation.enums;

public enum CampusTourOptions { ON_FOOT, BY_BUS };
