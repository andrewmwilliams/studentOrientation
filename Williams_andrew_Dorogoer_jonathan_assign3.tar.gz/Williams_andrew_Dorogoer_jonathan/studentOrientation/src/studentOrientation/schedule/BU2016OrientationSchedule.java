package studentOrientation.schedule;

import studentOrientation.enums.BookStoreEnum;
import studentOrientation.enums.BookStoreOptions;
import studentOrientation.enums.CampusTourOptions;
import studentOrientation.enums.DormEnum;
import studentOrientation.enums.DormOptions;
import studentOrientation.enums.RegistrationEnum;
import studentOrientation.enums.RegistrationOptions;
import studentOrientation.enums.TourEnum;
import studentOrientation.cost.BUCarbonFootprint;
import studentOrientation.cost.BUCost;
import studentOrientation.cost.BUDuration;
import studentOrientation.cost.BUEffort;
import studentOrientation.cost.CarbonFootprintInterface;
import studentOrientation.cost.CostInterface;
import studentOrientation.cost.DurationInterface;
import studentOrientation.cost.EffortInterface;
import studentOrientation.registrationOptions.AdminDorm;
import studentOrientation.registrationOptions.BookStoreInterface;
import studentOrientation.registrationOptions.BusTour;
import studentOrientation.registrationOptions.CampusBookStore;
import studentOrientation.registrationOptions.CampusTourInterface;
import studentOrientation.registrationOptions.DormInterface;
import studentOrientation.registrationOptions.MandoBookStore;
import studentOrientation.registrationOptions.OnFootTour;
import studentOrientation.registrationOptions.OnlineDorm;
import studentOrientation.registrationOptions.OnlineRegistration;
import studentOrientation.registrationOptions.RegistrarRegistration;
import studentOrientation.registrationOptions.RegistrationInterface;

public class BU2016OrientationSchedule extends OrientationSchedule {

/**
 *BU2016OrientationSchedule constructor
 *
 *@param tourOptionIn CampusTourOptions object
 *@param bookStoreIn BookStoreOptions object
 *@param dormChoiceIn DormOptions object
 *@param registrationMethodIn RegistrationOptions object
 */
    public BU2016OrientationSchedule(CampusTourOptions tourOptionIn, BookStoreOptions bookStoreIn, DormOptions dormChoiceIn, RegistrationOptions registrationMethodIn) {
	tourOption = tourOptionIn;
	bookStoreOption = bookStoreIn;
	dormOption = dormChoiceIn;
	registrationOption = registrationMethodIn;
    }
  /**
   *
   *Function builds the book store object
   *
   */
    public void buildBookStore() {
		if (bookStoreOption == BookStoreOptions.MANDO_BOOKS) {
			CostInterface cost = new BUCost(BookStoreEnum.MandoBookStore.cost);
			DurationInterface duration = new BUDuration(BookStoreEnum.MandoBookStore.duration);
			EffortInterface effort = new BUEffort(BookStoreEnum.MandoBookStore.effort);
			CarbonFootprintInterface carbonFootprint = new BUCarbonFootprint(BookStoreEnum.MandoBookStore.footprint);
		    bookStore = new MandoBookStore(carbonFootprint, duration, cost, effort);
		}
		else if (bookStoreOption == BookStoreOptions.CAMPUS_BOOK_STORE) {
			CostInterface cost = new BUCost(BookStoreEnum.CampusBookStore.cost);
			DurationInterface duration = new BUDuration(BookStoreEnum.CampusBookStore.duration);
			EffortInterface effort = new BUEffort(BookStoreEnum.CampusBookStore.effort);
			CarbonFootprintInterface carbonFootprint = new BUCarbonFootprint(BookStoreEnum.CampusBookStore.footprint);
		    bookStore = new CampusBookStore(carbonFootprint, duration, cost, effort);
		}
    }
/**
 *
 *Function builds a campus tour object
 */
    public void buildCampusTour() {
		if (tourOption == CampusTourOptions.ON_FOOT) {
			CostInterface cost = new BUCost(TourEnum.OnFoot.cost);
			DurationInterface duration = new BUDuration(TourEnum.OnFoot.duration);
			EffortInterface effort = new BUEffort(TourEnum.OnFoot.effort);
			CarbonFootprintInterface carbonFootprint = new BUCarbonFootprint(TourEnum.OnFoot.footprint);	
		    tour = new OnFootTour(carbonFootprint, duration, cost, effort);
		}
		else if (tourOption == CampusTourOptions.BY_BUS) {
			CostInterface cost = new BUCost(TourEnum.ByBus.cost);
			DurationInterface duration = new BUDuration(TourEnum.ByBus.duration);
			EffortInterface effort = new BUEffort(TourEnum.ByBus.effort);
			CarbonFootprintInterface carbonFootprint = new BUCarbonFootprint(TourEnum.ByBus.footprint);
	    	tour = new BusTour(carbonFootprint, duration, cost, effort);
		}
    }
/**
 *
 *Function builds a dorm object
 *
 *
 */
    public void buildDorm() {
		if (dormOption == DormOptions.ADMIN_OFFICE) {
			CostInterface cost = new BUCost(DormEnum.AdminOffice.cost);
			DurationInterface duration = new BUDuration(DormEnum.AdminOffice.duration);
			EffortInterface effort = new BUEffort(DormEnum.AdminOffice.effort);
			CarbonFootprintInterface carbonFootprint = new BUCarbonFootprint(DormEnum.AdminOffice.footprint);
		    dorm = new AdminDorm(carbonFootprint, duration, cost, effort);
		}
		else if (dormOption == DormOptions.ONLINE_CONTEST) {
			CostInterface cost = new BUCost(DormEnum.AdminOffice.cost);
			DurationInterface duration = new BUDuration(DormEnum.AdminOffice.duration);
			EffortInterface effort = new BUEffort(DormEnum.AdminOffice.effort);
			CarbonFootprintInterface carbonFootprint = new BUCarbonFootprint(DormEnum.AdminOffice.footprint);
		    dorm = new OnlineDorm(carbonFootprint, duration, cost, effort);
		}
    }
/**
 *
 *
 *Function builds a registration object
 *
 *
 */
    public void buildRegistration() {
		if (registrationOption == RegistrationOptions.REGISTRARS_OFFICE) {
			CostInterface cost = new BUCost(RegistrationEnum.Registrar.cost);
			DurationInterface duration = new BUDuration(RegistrationEnum.Registrar.duration);
			EffortInterface effort = new BUEffort(RegistrationEnum.Registrar.effort);
			CarbonFootprintInterface carbonFootprint = new BUCarbonFootprint(RegistrationEnum.Registrar.footprint);
		    registration = new RegistrarRegistration(carbonFootprint, duration, cost, effort);
		}
		else if (registrationOption == RegistrationOptions.COMPUTER_LAB) {
			CostInterface cost = new BUCost(RegistrationEnum.Online.cost);
			DurationInterface duration = new BUDuration(RegistrationEnum.Online.duration);
			EffortInterface effort = new BUEffort(RegistrationEnum.Online.effort);
			CarbonFootprintInterface carbonFootprint = new BUCarbonFootprint(RegistrationEnum.Online.footprint);
		   	registration = new OnlineRegistration(carbonFootprint, duration, cost, effort);
		}
    }
/**
 *
 *Prints the resulting cost, carbon footprint, duration, effort, ect...
 *
 */
    public void print() {
		double totalCost = tour.getCost() + bookStore.getCost() + registration.getCost() + dorm.getCost();
		double totalCarbon = tour.getFootprint() + bookStore.getFootprint() + registration.getFootprint() + dorm.getFootprint();
		double totalDuration = tour.getDuration() + bookStore.getDuration() + registration.getDuration() + dorm.getDuration();
		double totalEffort = tour.getEffort() + bookStore.getEffort() + registration.getEffort() + dorm.getEffort();

		System.out.printf("Books:\n\tcost: %.2f\n\tcarbon: %.2f\n\tduration: %.2f\n\teffort: %.2f\n", bookStore.getCost(), bookStore.getFootprint(), bookStore.getDuration(), bookStore.getEffort());
		System.out.printf("Dorm:\n\tcost: %.2f\n\tcarbon: %.2f\n\tduration: %.2f\n\teffort: %.2f\n", dorm.getCost(), dorm.getFootprint(), dorm.getDuration(), dorm.getEffort());
		System.out.printf("Registration:\n\tcost: %.2f\n\tcarbon: %.2f\n\tduration: %.2f\n\teffort: %.2f\n", registration.getCost(), registration.getFootprint(), registration.getDuration(), registration.getEffort());
		System.out.printf("Tour:\n\tcost: %.2f\n\tcarbon: %.2f\n\tduration: %.2f\n\teffort: %.2f\n", tour.getCost(), tour.getFootprint(), tour.getDuration(), tour.getEffort());
		System.out.printf("Totals:\n\tcost: %.2f\n\tcarbon: %.2f\n\tduration: %.2f\n\teffort: %.2f\n", totalCost, totalCarbon, totalDuration, totalEffort);
    }

    private CampusTourOptions tourOption;
    private BookStoreOptions bookStoreOption;
    private DormOptions dormOption;
    private RegistrationOptions registrationOption;

    private BookStoreInterface bookStore;
    private RegistrationInterface registration;
    private CampusTourInterface tour;
    private DormInterface dorm;
}
