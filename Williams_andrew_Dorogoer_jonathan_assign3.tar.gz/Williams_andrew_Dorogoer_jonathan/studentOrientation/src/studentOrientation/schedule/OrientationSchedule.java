package studentOrientation.schedule;

public abstract class OrientationSchedule {
    public abstract void buildCampusTour();
    public abstract void buildBookStore();
    public abstract void buildDorm();
    public abstract void buildRegistration();

    public abstract void print();
}
