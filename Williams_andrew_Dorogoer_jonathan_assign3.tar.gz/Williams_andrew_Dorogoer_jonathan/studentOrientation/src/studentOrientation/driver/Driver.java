package studentOrientation.driver;

import studentOrientation.schedule.OrientationSchedule;
import studentOrientation.schedule.BU2016OrientationSchedule;
import studentOrientation.enums.CampusTourOptions;
import studentOrientation.enums.DormOptions;
import studentOrientation.enums.BookStoreOptions;
import studentOrientation.enums.RegistrationOptions;
import studentOrientation.workshop.BU2016OrientationWorkshop;
import studentOrientation.workshop.FreshmanOrientationWorkshop;

public class Driver {
    public static void main(String[] args) {
		OrientationSchedule sched = new BU2016OrientationSchedule(CampusTourOptions.ON_FOOT, BookStoreOptions.MANDO_BOOKS, DormOptions.ADMIN_OFFICE, RegistrationOptions.REGISTRARS_OFFICE);

	FreshmanOrientationWorkshop shop = new BU2016OrientationWorkshop();
	
	shop.construct(sched);

	sched.print();
    }
}
