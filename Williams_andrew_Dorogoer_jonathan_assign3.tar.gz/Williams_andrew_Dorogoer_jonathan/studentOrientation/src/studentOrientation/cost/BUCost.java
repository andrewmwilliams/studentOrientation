package studentOrientation.cost;

public class BUCost implements CostInterface {

/**
 *Sets an initial cost value for cost
 *
 *@param costIn a passed cost value
 */
    public BUCost(double costIn) {
	cost = costIn;
    }
/**
 *Sets the cost to a modVal + cost
 *
 *@param modVal modification value
 */
    public void modify(double modVal) {
	cost += modVal;
    }
/**
 *Function returns a cost value
 *
 *@return returns a double value of cost
 */
    public double get() {
	return cost;
    }

    private double cost;
}
