package studentOrientation.cost;

public interface DurationInterface {
    public void modify(double modVal);
    public double get();
}
