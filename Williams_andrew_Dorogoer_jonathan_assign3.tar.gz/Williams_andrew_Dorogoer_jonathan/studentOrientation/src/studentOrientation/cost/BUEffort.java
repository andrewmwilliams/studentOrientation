package studentOrientation.cost;

public class BUEffort implements EffortInterface {
/**
 *Takes a effort value and sets the intial effort of the instance
 *@param effortIn effort value
 */
    public BUEffort(double effortIn) {
	effort = effortIn;
    }

/**
 *Takes a modVal and sets effort to modVal + effort
 *
 *@param modVal modification value
 */
    public void modify(double modVal) {
	effort += modVal;
    }

/**
 *Gets the value of effort
 *
 *@return returns a effort value in a double
 */
    public double get() {
	return effort;
    }    
    
    private double effort;
    
}
