package studentOrientation.cost;

public class BUCarbonFootprint implements CarbonFootprintInterface {

    /**
     * This contructor sets the footprint to a value
     *
     *@param footprintIn carbon foot print value
     */
    public BUCarbonFootprint(double footprintIn) {
		footprint = footprintIn;
    }


/**
 *Modifies the footprint to modVal + footprint
 *
 *@param modVal modification value
 */
    public void modify(double modVal) {
	footprint += modVal;
    }
/**
 *Returns a footprint value
 *
 *@return returns the footprint 
 */
    public double get() {
	return footprint;
    }

    private double footprint;
}
