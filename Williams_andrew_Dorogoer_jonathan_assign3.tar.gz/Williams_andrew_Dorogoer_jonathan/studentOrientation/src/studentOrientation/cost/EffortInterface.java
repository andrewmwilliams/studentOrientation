package studentOrientation.cost;

public interface EffortInterface {
    public void modify(double modVal);
    public double get();
}
