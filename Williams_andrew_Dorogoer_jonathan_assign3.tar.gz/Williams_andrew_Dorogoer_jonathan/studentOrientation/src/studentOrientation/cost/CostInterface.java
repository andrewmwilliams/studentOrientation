package studentOrientation.cost;

public interface CostInterface {
    public void modify(double modVal);
    public double get();
}
