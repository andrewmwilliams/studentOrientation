package studentOrientation.cost;

public class BUDuration implements DurationInterface {
    
    /**
     *Takes a duration value and sets the intial duration of the instance
     *@param durationIn duration value
     */
    public BUDuration(double durationIn) {
	duration = durationIn;
    }


/**
 *Takes a modVal and sets duration to modVal + duration
 *
 *@param modVal modification value
 */
    public void modify(double modVal) {
	duration += modVal;
    }
/**
 *Gets the value of duration
 *
 *@return returns a duration value in a double
 */
    public double get() {
	return duration;
    }

    private double duration;
}
