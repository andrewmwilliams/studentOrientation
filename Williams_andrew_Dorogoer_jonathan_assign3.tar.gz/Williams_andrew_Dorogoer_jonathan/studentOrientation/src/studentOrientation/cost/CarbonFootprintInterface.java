package studentOrientation.cost;

public interface CarbonFootprintInterface {
    public void modify(double modVal);
    public double get();
}
