package studentOrientation.registrationOptions;

import studentOrientation.cost.CarbonFootprintInterface;
import studentOrientation.cost.CostInterface;
import studentOrientation.cost.DurationInterface;
import studentOrientation.cost.EffortInterface;

public class OnlineDorm implements DormInterface {
    
/**
 *OnlineDorm contructor
 *
 *@param carbonFootprintIn initial CarbonFootprintInterface 
 *@param durationIn intial durationIn
 *@param costIn intial costIn
 *@param effortIn intial effortIn
 */

	public OnlineDorm(CarbonFootprintInterface carbonFootprintIn, DurationInterface durationIn, CostInterface costIn, EffortInterface effortIn) {
		carbonFootprint = carbonFootprintIn;
		duration = durationIn;
		cost = costIn;
		effort = effortIn;
    }
/**
 *Gets cost from cost object
 * 
 *@return returns cost within cost object
 */

	public double getCost() {
		return cost.get();
	}
/**
 *Gets the carbonFootprint value for the carbonFootprint object
 *
 *@return returns a carbonFootprint value
 */

	public double getFootprint() {
		return carbonFootprint.get();
	}
/**
 *
 *Gets the duration value of duration the object
 *
 *@return returns duration value
 */

	public double getDuration() {
		return duration.get();
	}
/**
 *Gets the effort value from the effort object
 *
 *@return returns the effort value
 */

	public double getEffort() {
		return effort.get();
	}
    private CarbonFootprintInterface carbonFootprint;
    private DurationInterface duration;
    private CostInterface cost;
    private EffortInterface effort;
}
