package studentOrientation.registrationOptions;

public interface DormInterface {
    public double getCost();
	public double getFootprint();
	public double getDuration();
	public double getEffort();
}
